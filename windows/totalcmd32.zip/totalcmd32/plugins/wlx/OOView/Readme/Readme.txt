"OpenOffice.org Simple Viewer" plugin for Total Commander
---------------------------------------------------------
This plugin allows to view OpenOffice.org documents.
Document contents is currently shown without formatting - only plain text.
The following file extensions are handled:
.ODT .ODS .ODP .ODG .ODF .ODB .ODM .OTT .OTH .OTS .OTG .OTP
.SXW .SXC .SXG .SXI .SXD .SXM .STW .STC .STD .STI.


Installation
------------
With TC 6.50+, just open archive and TC will install plugin automatically.
If you already have plugin installed, you may first need to uninstall
previous version (so plugin's detect string will be updated).


(c) Alexey Torgashin
Homepage:
http://totalcmd.net/plugring/OOSimpleViewer.html
