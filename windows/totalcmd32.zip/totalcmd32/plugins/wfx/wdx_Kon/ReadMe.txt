TotalConsole  - WFX,WDX plugin for Total Commander
====================================================
Copyright (c) 2007 by Dmitry Kolomiets aka B4rr4cuda.

This is distributed under the GNU GPL. See LICENSE.txt for the license terms.

