UnInstaller v1.8.1 - FS-plugin for Total Commander 5.51 and above
----------------------------------------------------------------

Enhanced plugin for uninstalling different software. The same as 
Control Panel - "Add\Remove program", but more powerful and convenient.

Capacityes:
------------
   - Show all records for uninstall program 
     (hidden also) 
   - Uninstall program                        ("Enter")
   - View all properties of record            ("F3" or "Ctrl-Q")
   - Delete incorrect links                   ("Del" or "F8")
   - Edit some properties of record           ("Alt"+"Enter")
   - Config plugin                            ("Alt"+"Enter" in Network Neighborhood)


Installation
------------
1. Unzip the archive to an empty directory
2. Choose Configuration - Options - Operation - FS-Plugins
3. Click "Add"
4. Go to the directory where the archive was unzipped, and select UnInstTC.wfx
5. Click OK. You can now access the plugin in "Network Neighborhood"


Enjoy
---------------------
Skarednyi Igor (Gosha)
e-mail: prof@atnet.ru
