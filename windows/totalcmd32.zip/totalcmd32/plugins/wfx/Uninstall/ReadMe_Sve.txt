UnInstaller v1.7.3 - FS-plugin f�r Total Commander 5.51 och h�gre
-----------------------------------------------------------------

Insticksmodul f�r att avinstallera program. Samma som
Kontrollpanelen - "L�gg till\ta bort program", men bekv�mare och med fler funktioner.

Funktioner:
------------
   - Show all records for uninstall program 
     (�ven dolda) 
   - Avinstallera program                     ("Enter")
   - Visa postens alla egenskaper             ("F3" eller "Ctrl-Q")
   - Ta bort felaktiga l�nkar                 ("Del" eller "F8")
   - Redigera egenskaper f�r post             ("Alt"+"Enter")
   - Konfigurera insticksmodulen (plugin)     ("Alt"+"Enter" i N�tverk)


Installation
------------
1. Zippa upp arkivet i en tom mapp
2. V�lj Konfigurera - Generella inst�llningar - Funktioner - FS-plugins
3. V�lj "L�gg till"
4. G� till mappen d�r du zippade upp arkivet och v�lj UnInstTC.wfx
5. Klicka p� OK. Nu kommer du �t denna insticksmodul (plugin) i "N�tverk"


Mycket n�je
---------------------
Skarednyi Igor (Gosha)
e-mail: prof@atnet.ru
