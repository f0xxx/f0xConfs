UnInstaller v1.7.3 - FS-plugin for Total Commander 5.51 and above
----------------------------------------------------------------

Module voor het de-installeren van verschillende software. Hetzelfde als
Configuratiescherm - "Software", maar krachtiger en gebruiksvriendelijker.

Mogelijkheden:
------------
   - Toon alle programma's om te de-installeren (ook verborgen) 
   - De-installeer programma                   ("Enter")
   - Toon alle eigenschappen van programma     ("F3" or "Ctrl-Q")
   - Verwijdere incorrecte links               ("Del" or "F8")
   - Wijzig aantal eigenschappen van programma ("Alt"+"Enter")
   - Configureer module                        ("Alt"+"Enter" in Mijn Netwerklocaties)


Installatie
------------
1. Unzip het archief in een lege map
2. Kies Configuratie - Opties - Plugins - Plugins voor bestandssystemen Configureren
3. Klik "Toevoegen"
4. Ga naar de map waar het archief in uitgepakt is en selecteer UnInstTC.wfx
5. Klik OK. De module is nu te benaderen vanuit "Mijn netwerklocaties"


Veel plezier
---------------------
Skarednyi Igor (Gosha)
e-mail: prof@atnet.ru
Vertaald: Roland Dalmulder (rdalmulder@hotmail.com)
