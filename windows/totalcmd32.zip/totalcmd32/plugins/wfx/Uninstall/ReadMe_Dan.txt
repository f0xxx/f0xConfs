UnInstaller v1.8.1 - FS-plugin for Total Commander 5.51 og nyere
----------------------------------------------------------------

Udvidet plugin for afinstallering af forskellig software. Det samme som
Kontrolpanel - "Tilf�j\Fjern programmer", men med flere muligheder og mere bekvem.

Egenskaber:
------------
   - Vis alle registreringer om afinstallationsprogrammet
     (ogs� skjulte) 
   - Afinstallation                           ("Enter")
   - Vis alle registreringer                  ("F3" eler "Ctrl+Q")
   - Slet ukorrekte links                     ("Del" eller "F8")
   - Rediger visse registreringer             ("Alt"+"Enter")
   - Konfigurer plugin                        ("Alt"+"Enter" i Netv�rkssteder)


Installation
------------
1. udpak arkivet til en tom mappe
2. V�lg Ops�tnong - Indstillinger - Plugins - Filsystem-plugins - Konfigurer
3. Klik p� "Tilf�j"
4. G� til den mappe, hvortil arkivet blev udpakket, og v�lg UnInstTC.wfx
5. Klik OK. Du kan nu f� adgang til pluginet i "Netv�rkssteder"


God forn�jelse
---------------------
Skarednyi Igor (Gosha)
e-mail: prof@atnet.ru
